# Play A Sound - A Chrome extension
This Chrome extension will play a sound so you can check if your audio works!
